/****************************************************************************************
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
$Esto es un comentario multilinea y puede venir en cualquier parte del archivo de entrada$
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
*****************************************************************************************/

import ClaseA;
import ClaseB; 

class prueba_entrada1 {


    int metodo_1(int a,int b,int c,String d, double Double,int INT){
        if(a + b + c / Double * INT){
            return 0;
        }else{
            return 1;
        }
    }


    String metodo_2(boolean falso){
        if(falso){
            return "Entro falco como verdadero";
        }else if(!!falso){
            return "Entro falco como verdadero";
        }else if(!!!!falso){
            return "Entro falco como verdadero";
        }else if(!!!!!falso){
            return "Entro falco como verdadero";
        }else if(!!!!!!!!falso){
            return "Entro falco como verdadero";
        }else if(!!!!!!!!!falso){
            return "Entro falco como verdadero";
        }else if(!!!!!!!!!!!falso){
            return "Entro falco como verdadero";
        }else if(!!!!!!!!!!!!falso){
            return "Entro falco como verdadero";
        }else if(!!!!!!!!!!!!falso){
            return "Entro falco como verdadero";
        }else if(!!!!!!!!!!!!!!!!!falso){
            return "Entro falco como verdadero";
        }else if(!!!!!!!!!!!!!falso){
            return "Entro falco como verdadero";
        }else if(!!!!!!!!!!!!falso){
            return "Entro falco como verdadero";
        }
    }


    double relacionales(/*Comentario multilinea no afecta la ejecucion*/){
        while(true){
            while(1){
                int x = 0;
                do{
                    System.out.println("0777-Compiladores 1"); 
                    if(x >= 20){
                        break;
                    }
                }while(x>50000);

                if((1>2) == (3<5)){
                    System.out.println("Es incorrecto");
                }else if((1-2+4-3+5*(7/6+4-6))>(1-2+4-3*(67))){
                    System.out.println("Sera incorrecto?");
                }else{
                     System.out.println("Entro al else");
                }


                break;
            }
        }

        return "String no es un double";
    }


    double logicas(boolean a, boolean b, boolean c){
        for(int x=-1;x<100;x++){
            for(int y=2;x*y<30;y++){
                int xyz=5;
                double Double = 0.00000000010293856378019283645329201;
                String string = "string";
                char CHAR_1 = ' ';
            }
        }
    }


    void main(){
        double logicas = logicas(true,1==1,!!!!!!!!!(true && true)||(!true && !!!!!!false) && false);
        double rel = relacionales();
        String response = metodo_2(!false && true || !true);
        int a = 67;
        int v = 12;
        int z = 0;
        int b = -123456;

        String parametro = "Este texto se envio como parametro";

        int __________ultimo_parametro = 10;

        int entero = metodo_1(4*a-v+z,b,a-23,parametro,-0.09,__________ultimo_parametro)
    }
}


class prueba_2{

    int switch(){
        int a,b,c,d,g,j,l = 8;
        double cdf,var1,var2,var3 = 0.0;
        String str1,str2,str3 = "cadena de str;";
        String micadena = "Concatenacion de cadenas: " + str1 + str2 + str3;

        switch (3*54) {      
            case 3: 
                System.out.print(micadena);          
                break;      
            case 5:     
                System.out.print(micadena);
            case 7:       
                System.out.print(micadena);
                break;      
            default:   
                System.out.print(micadena);      
                break; 
        } 

    }

    double potencia(double n1, double n2){
        double resultado = n1^ n2;
        return resultado;  
    } 

    void main(){
        potencia(0.1,5);
    }
}